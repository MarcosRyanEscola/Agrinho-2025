let tractor;
let wheats = [];
let wheatCount = 0;
let timeLeft = 20; // Tempo do jogo: 20 segundos
let gameRunning = true;
let timerStartTime;

const GAME_WIDTH = 600;
const GAME_HEIGHT = 400;
const TRACTOR_WIDTH = 80;
const TRACTOR_HEIGHT = 60;
const HARVESTER_WIDTH = 50; // Largura da colheitadeira (lateral)
const HARVESTER_HEIGHT = 100; // Altura da colheitadeira
const WHEAT_SIZE = 28;
const MOVEMENT_SPEED = 4;

// Definindo a área do campo para o trator e o trigo
const FIELD_TOP = GAME_HEIGHT * 0.4; // Onde o campo começa (mesmo que o desenho)
const FIELD_BOTTOM = GAME_HEIGHT; // Onde o campo termina

function setup() {
    createCanvas(GAME_WIDTH, GAME_HEIGHT);
    // Inicia o trator no meio da parte inferior do campo, ajustado para não ir para o céu
    tractor = new Tractor(GAME_WIDTH / 2 - TRACTOR_WIDTH / 2, FIELD_BOTTOM - TRACTOR_HEIGHT - 10, TRACTOR_WIDTH, TRACTOR_HEIGHT);
    timerStartTime = millis();

    // Spawna alguns trigos iniciais
    for (let i = 0; i < 7; i++) {
        spawnWheat();
    }
}

function draw() {
    // Fundo do céu
    background(135, 206, 250); // Azul mais vibrante

    // Desenha o sol
    noStroke();
    fill(255, 200, 0); // Amarelo sol
    ellipse(width - 80, 80, 80, 80);

    // Nuvens com mais detalhes
    drawCloud(100, 50, 60);
    drawCloud(250, 70, 50);
    drawCloud(450, 60, 70);

    // Campo
    fill(139, 69, 19); // Marrom terra para o campo
    rect(0, FIELD_TOP, GAME_WIDTH, FIELD_BOTTOM - FIELD_TOP); // Usa as constantes para o campo
    // Pequenas marcas no campo para dar a ideia de textura
    stroke(120, 50, 10);
    strokeWeight(1);
    for (let i = 0; i < GAME_WIDTH; i += 15) {
        line(i, FIELD_TOP + 5, i + 10, FIELD_TOP + 15);
    }
    noStroke();


    if (gameRunning) {
        // Atualiza o tempo
        let elapsedTime = (millis() - timerStartTime) / 1000;
        timeLeft = 20 - floor(elapsedTime); // Tempo reduzido para 20 segundos

        if (timeLeft <= 0) {
            endGame(false);
        }

        // Movimentação e desenho do trator
        tractor.move();
        tractor.display();

        // Desenha e verifica colisão com trigos
        for (let i = wheats.length - 1; i >= 0; i--) {
            wheats[i].display();
            // A colisão agora é verificada pela colheitadeira do trator
            if (tractor.harvesterCollidesWith(wheats[i])) {
                wheats.splice(i, 1);
                wheatCount++;
                spawnWheat();
            }
        }

        // Exibe score e tempo
        fill(0);
        textSize(18);
        textAlign(LEFT, TOP);
        text(`Trigos Colhidos: ${wheatCount} - Objetivo: 50 Trigos`, 10, 10);
        text(`Tempo: ${max(0, timeLeft)}s`, 10, 35);

        // --- Adição da mensagem de instrução aqui ---
        fill(0); // Cor do texto preta
        textSize(16); // Tamanho da fonte menor para a instrução
        textAlign(LEFT, BOTTOM); // Alinha o texto à esquerda e na parte inferior
        text("Use as setas do teclado para se locomover.", 10, GAME_HEIGHT - 10);
        // --- Fim da adição ---

        // Verifica condição de vitória
        if (wheatCount >= 50) {
            endGame(true);
        }

    } else {
        // Exibe a mensagem final
        fill(0, 0, 0, 200);
        rectMode(CENTER);
        rect(width / 2, height / 2, 400, 120, 10);

        fill(255);
        textSize(36);
        textAlign(CENTER, CENTER);
        if (wheatCount >= 50) {
            text("GANHOU O JOGO!", width / 2, height / 2 - 20);
            textSize(24);
            text(`Você colheu ${wheatCount} trigos!`, width / 2, height / 2 + 20);
        } else {
            text("PERDEU O JOGO!", width / 2, height / 2 - 20);
            textSize(24);
            text(`Você colheu ${wheatCount} trigos.`, width / 2, height / 2 + 20);
        }
    }
}

// Função auxiliar para desenhar nuvens
function drawCloud(x, y, baseSize) {
    fill(255, 255, 255, 220); // Nuvens brancas semi-transparentes
    noStroke();
    ellipse(x, y, baseSize * 1.2, baseSize * 0.8);
    ellipse(x + baseSize * 0.4, y - baseSize * 0.2, baseSize, baseSize * 0.7);
    ellipse(x - baseSize * 0.3, y - baseSize * 0.1, baseSize * 0.9, baseSize * 0.6);
    ellipse(x + baseSize * 0.8, y, baseSize * 0.7, baseSize * 0.5);
}


// Classe para o Trator com Colheitadeira Dinâmica e Aprimorada
class Tractor {
    constructor(x, y, w, h) {
        this.x = x;
        this.y = y;
        this.w = w; // largura do corpo do trator
        this.h = h; // altura do corpo do trator
        this.harvesterW = HARVESTER_WIDTH;
        this.harvesterH = HARVESTER_HEIGHT;
        this.harvesterSide = 'right'; // 'left' ou 'right', padrão para direita
    }

    display() {
        noStroke();

        // --- Corpo do Trator ---
        // Chassi inferior e eixo (cinza escuro)
        fill(60, 60, 60);
        rect(this.x, this.y + this.h * 0.6, this.w, this.h * 0.2, 5); // Chassi
        rect(this.x + this.w * 0.1, this.y + this.h * 0.5, this.w * 0.05, this.h * 0.2); // Conexão roda dianteira
        rect(this.x + this.w * 0.85, this.y + this.h * 0.5, this.w * 0.05, this.h * 0.2); // Conexão roda traseira

        // Corpo principal (vermelho vivo)
        fill(200, 0, 0); // Vermelho vibrante
        rect(this.x, this.y + this.h * 0.1, this.w * 0.7, this.h * 0.6, 8); // Base do corpo
        rect(this.x + this.w * 0.6, this.y + this.h * 0.2, this.w * 0.4, this.h * 0.4, 5); // Motor mais quadrado

        // Grades do motor (preto)
        fill(30, 30, 30);
        rect(this.x + this.w * 0.65, this.y + this.h * 0.25, this.w * 0.05, this.h * 0.3, 2);
        rect(this.x + this.w * 0.75, this.y + this.h * 0.25, this.w * 0.05, this.h * 0.3, 2);

        // Cabine (azul escuro com janelas mais realistas)
        fill(50, 100, 150); // Azul petróleo
        rect(this.x + this.w * 0.3, this.y - this.h * 0.35, this.w * 0.55, this.h * 0.6, 8); // Cabine

        fill(170, 220, 255); // Azul claro para janelas
        // Janela frontal
        rect(this.x + this.w * 0.35, this.y - this.h * 0.25, this.w * 0.2, this.h * 0.45, 3);
        // Janela lateral (simulada)
        rect(this.x + this.w * 0.58, this.y - this.h * 0.25, this.w * 0.25, this.h * 0.45, 3);
        stroke(0); // Bordas das janelas
        strokeWeight(1);
        line(this.x + this.w * 0.58, this.y - this.h * 0.25, this.x + this.w * 0.58, this.y + this.h * 0.2);
        noStroke();

        // Rodas (preto fosco com detalhes em cinza)
        fill(10, 10, 10); // Preto mais fosco
        ellipse(this.x + this.w * 0.25, this.y + this.h * 0.85, this.w * 0.4, this.w * 0.4); // Roda dianteira
        ellipse(this.x + this.w * 0.85, this.y + this.h * 0.85, this.w * 0.5, this.w * 0.5); // Roda traseira

        fill(80, 80, 80); // Cinza para o aro interno
        ellipse(this.x + this.w * 0.25, this.y + this.h * 0.85, this.w * 0.2, this.w * 0.2);
        ellipse(this.x + this.w * 0.85, this.y + this.h * 0.85, this.w * 0.3, this.w * 0.3);

        // Cubos das rodas (prata)
        fill(190, 190, 190);
        ellipse(this.x + this.w * 0.25, this.y + this.h * 0.85, this.w * 0.08, this.w * 0.08);
        ellipse(this.x + this.w * 0.85, this.y + this.h * 0.85, this.w * 0.12, this.w * 0.12);

        // Escapamento (cromado)
        fill(150, 150, 150);
        rect(this.x + this.w * 0.8, this.y - this.h * 0.45, this.w * 0.08, this.h * 0.4, 4); // Escapamento
        fill(100, 100, 100);
        ellipse(this.x + this.w * 0.8 + this.w * 0.04, this.y - this.h * 0.45, this.w * 0.08, this.w * 0.03); // Topo do escapamento

        // --- Colheitadeira Lateral Melhorada ---
        let harvesterX;
        let harvesterY = this.y + this.h * 0.1; // Ajusta para que o topo da colheitadeira esteja na altura da cabine

        if (this.harvesterSide === 'right') {
            harvesterX = this.x + this.w; // À direita do trator
        } else { // 'left'
            harvesterX = this.x - this.harvesterW; // À esquerda do trator
        }

        // Base da colheitadeira (verde escuro)
        fill(34, 139, 34); // Verde floresta
        rect(harvesterX, harvesterY, this.harvesterW, this.harvesterH, 5);

        // Parte superior da colheitadeira (cinza metálico)
        fill(120, 120, 120);
        rect(harvesterX + this.harvesterW * 0.1, harvesterY, this.harvesterW * 0.8, this.harvesterH * 0.2, 3);

        // Lâmina de corte (laranja vibrante)
        fill(255, 100, 0); // Laranja vivo
        rect(harvesterX, harvesterY + this.harvesterH * 0.8, this.harvesterW, this.harvesterH * 0.2, 3);

        // Dentes da lâmina (pequenos triângulos)
        fill(255, 160, 0); // Laranja mais claro
        for (let i = 0; i < this.harvesterW; i += 10) {
            triangle(harvesterX + i, harvesterY + this.harvesterH,
                     harvesterX + i + 5, harvesterY + this.harvesterH,
                     harvesterX + i + 2.5, harvesterY + this.harvesterH + 5);
        }

        // Rolo giratório (amarelo claro com barras)
        fill(255, 255, 100); // Amarelo bem claro
        ellipse(harvesterX + this.harvesterW * 0.5, harvesterY + this.harvesterH * 0.5, this.harvesterW * 0.7, this.harvesterH * 0.4);

        // Barras do rolo (marrom)
        stroke(100, 70, 0);
        strokeWeight(2);
        line(harvesterX + this.harvesterW * 0.2, harvesterY + this.harvesterH * 0.5 - this.harvesterH * 0.15,
             harvesterX + this.harvesterW * 0.8, harvesterY + this.harvesterH * 0.5 + this.harvesterH * 0.15);
        line(harvesterX + this.harvesterW * 0.2, harvesterY + this.harvesterH * 0.5 + this.harvesterH * 0.15,
             harvesterX + this.harvesterW * 0.8, harvesterY + this.harvesterH * 0.5 - this.harvesterH * 0.15);
        noStroke();

        // Conexão com o trator (cinza escuro)
        fill(80, 80, 80);
        if (this.harvesterSide === 'right') {
            rect(this.x + this.w - 5, this.y + this.h * 0.4, 10, this.h * 0.2, 3);
        } else {
            rect(this.x - 5, this.y + this.h * 0.4, 10, this.h * 0.2, 3);
        }
    }

    move() {
        if (keyIsDown(UP_ARROW)) {
            // Limita o movimento superior do trator ao topo do campo
            this.y = max(FIELD_TOP, this.y - MOVEMENT_SPEED);
        }
        if (keyIsDown(DOWN_ARROW)) {
            // Limita o movimento inferior do trator ao fundo da tela (ou campo)
            this.y = min(GAME_HEIGHT - this.h, this.y + MOVEMENT_SPEED);
        }
        if (keyIsDown(LEFT_ARROW)) {
            this.x = max(0, this.x - MOVEMENT_SPEED);
            this.harvesterSide = 'left'; // Muda a colheitadeira para a esquerda
        }
        if (keyIsDown(RIGHT_ARROW)) {
            this.x = min(GAME_WIDTH - this.w, this.x + MOVEMENT_SPEED);
            this.harvesterSide = 'right'; // Muda a colheitadeira para a direita
        }
    }

    harvesterCollidesWith(wheat) {
        let harvesterCollisionX;
        if (this.harvesterSide === 'right') {
            harvesterCollisionX = this.x + this.w;
        } else {
            harvesterCollisionX = this.x - this.harvesterW;
        }

        const harvesterCollisionY = this.y + this.h * 0.1 + (HARVESTER_HEIGHT * 0.4);
        const harvesterCollisionW = this.harvesterW;
        const harvesterCollisionH = HARVESTER_HEIGHT * 0.6;

        const isColliding = (
            harvesterCollisionX < wheat.x + wheat.size &&
            harvesterCollisionX + harvesterCollisionW > wheat.x &&
            harvesterCollisionY < wheat.y + wheat.size &&
            harvesterCollisionY + harvesterCollisionH > wheat.y
        );

        return isColliding;
    }
}

// Classe para o Trigo (mantida)
class Wheat {
    constructor(x, y, size) {
        this.x = x;
        this.y = y;
        this.size = size;
    }

    display() {
        noStroke();

        // Haste principal (verde acinzentado)
        fill(100, 140, 70); // Verde oliva
        rect(this.x + this.size * 0.48, this.y + this.size * 0.5, this.size * 0.05, this.size * 0.5, 2);

        // Base da espiga (marrom claro)
        fill(180, 160, 90); // Cor de palha
        ellipse(this.x + this.size / 2, this.y + this.size * 0.45, this.size * 0.6, this.size * 0.3);

        // Grãos da espiga (segmentos de elipse)
        fill(255, 223, 0); // Ouro puro
        const numSegments = 5;
        const segmentHeight = (this.size * 0.5) / numSegments;

        for (let i = 0; i < numSegments; i++) {
            let segY = this.y + this.size * 0.1 + i * segmentHeight;
            let segWidth = this.size * 0.6 * (1 - i * 0.1); // Diminui o tamanho conforme sobe
            ellipse(this.x + this.size / 2, segY, segWidth, segmentHeight * 1.5); // Elipses alongadas
        }

        // Detalhes dos grãos (pontos)
        fill(200, 180, 0); // Amarelo mais escuro
        for (let i = 0; i < numSegments; i++) {
            let segY = this.y + this.size * 0.1 + i * segmentHeight;
            let segWidth = this.size * 0.6 * (1 - i * 0.1);
            // Pontos à esquerda
            ellipse(this.x + this.size / 2 - segWidth / 2 + 3, segY, 3, 3);
            // Pontos à direita
            ellipse(this.x + this.size / 2 + segWidth / 2 - 3, segY, 3, 3);
        }


        // Pequenas "barbas" da espiga (linhas finas)
        stroke(150, 120, 0); // Marrom amarelado
        strokeWeight(0.8);
        line(this.x + this.size / 2, this.y, this.x + this.size * 0.4, this.y + this.size * 0.05);
        line(this.x + this.size / 2, this.y, this.x + this.size * 0.6, this.y + this.size * 0.05);
        line(this.x + this.size * 0.45, this.y + this.size * 0.1, this.x + this.size * 0.3, this.y + this.size * 0.2);
        line(this.x + this.size * 0.55, this.y + this.size * 0.1, this.x + this.size * 0.7, this.y + this.size * 0.2);
        noStroke();
    }
}

// Função para gerar um novo trigo
function spawnWheat() {
    let randomX = floor(random(0, GAME_WIDTH - WHEAT_SIZE));
    // Garante que o trigo spawne apenas na área do "campo"
    let randomY = floor(random(FIELD_TOP + WHEAT_SIZE, FIELD_BOTTOM - WHEAT_SIZE - 5)); // Spawna dentro da área do campo
    let newWheat = new Wheat(randomX, randomY, WHEAT_SIZE);
    wheats.push(newWheat);
}

// Função para encerrar o jogo
function endGame(win) {
    gameRunning = false;
}